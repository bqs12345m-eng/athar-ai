"""ATHAR AI evidence verifier — deterministic local checks only."""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any


VALID_STATUSES = {
    "VERIFIED",
    "PARTIAL",
    "FAILED",
    "INSUFFICIENT_EVIDENCE",
}


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def verify_task(task: dict[str, Any]) -> dict[str, Any]:
    """Verify supplied evidence against declared requirements.

    This function checks only the evidence payload included in `task`.
    It does not independently observe the system that allegedly performed
    the task.
    """
    task_id = str(task.get("task_id", "UNSPECIFIED"))
    requirements = task.get("requirements", [])
    evidence_items = task.get("evidence", [])

    if not isinstance(requirements, list) or not isinstance(evidence_items, list):
        raise ValueError("'requirements' and 'evidence' must both be lists")

    evidence_by_id: dict[str, dict[str, Any]] = {}
    for item in evidence_items:
        if isinstance(item, dict) and item.get("evidence_id") is not None:
            evidence_by_id[str(item["evidence_id"])] = item

    checks: list[dict[str, Any]] = []
    passed = 0
    missing = 0
    failed = 0

    for index, requirement in enumerate(requirements, start=1):
        if not isinstance(requirement, dict):
            raise ValueError(f"Requirement #{index} must be an object")

        req_id = str(requirement.get("requirement_id", f"REQ-{index}"))
        evidence_id = str(requirement.get("evidence_id", ""))
        evidence = evidence_by_id.get(evidence_id)

        result = {
            "requirement_id": req_id,
            "evidence_id": evidence_id,
            "status": None,
            "checks": [],
        }

        if not evidence or not isinstance(evidence.get("content"), str):
            result["status"] = "MISSING"
            result["reason"] = "Required evidence is missing or has no text content."
            missing += 1
            checks.append(result)
            continue

        content = evidence["content"]
        content_hash = sha256_text(content)
        requirement_failed = False
        criteria_count = 0

        expected_contains = requirement.get("expected_contains")
        if expected_contains is not None:
            criteria_count += 1
            ok = str(expected_contains) in content
            result["checks"].append({
                "type": "expected_contains",
                "expected": str(expected_contains),
                "passed": ok,
            })
            requirement_failed = requirement_failed or not ok

        expected_hash = requirement.get("expected_sha256")
        if expected_hash is not None:
            criteria_count += 1
            ok = str(expected_hash).lower() == content_hash
            result["checks"].append({
                "type": "expected_sha256",
                "expected": str(expected_hash).lower(),
                "actual": content_hash,
                "passed": ok,
            })
            requirement_failed = requirement_failed or not ok

        if criteria_count == 0:
            result["status"] = "UNVERIFIABLE"
            result["reason"] = "No verification criterion was defined for this requirement."
            missing += 1
        elif requirement_failed:
            result["status"] = "FAILED"
            result["actual_sha256"] = content_hash
            failed += 1
        else:
            result["status"] = "PASSED"
            result["actual_sha256"] = content_hash
            passed += 1

        checks.append(result)

    total = len(requirements)
    if total == 0:
        status = "INSUFFICIENT_EVIDENCE"
    elif failed:
        status = "FAILED"
    elif passed == total:
        status = "VERIFIED"
    elif passed > 0:
        status = "PARTIAL"
    else:
        status = "INSUFFICIENT_EVIDENCE"

    return {
        "schema_version": "1.0",
        "product": "ATHAR AI",
        "task_id": task_id,
        "claim": task.get("claim", ""),
        "status": status,
        "summary": {
            "total_requirements": total,
            "passed": passed,
            "missing_or_unverifiable": missing,
            "failed": failed,
        },
        "checks": checks,
        "limitations": [
            "Only supplied evidence was checked.",
            "This report does not independently prove the origin or authenticity of evidence.",
            "No external system or agent execution was observed.",
        ],
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
